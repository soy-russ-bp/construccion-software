package controlador;

public class ControladorIngreso {

}
