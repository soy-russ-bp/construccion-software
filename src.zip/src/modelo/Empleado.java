package modelo;

import java.util.List;

public class Empleado extends Usuario {
	public void marcarPedidoEntregado(Pedido pedido) {
		
	}
	
	public void registrarCobro(Pedido pedido) {
		
	}
	
	public List<Pedido> verPedidosPendientes() {
		return null;	
	}
}
