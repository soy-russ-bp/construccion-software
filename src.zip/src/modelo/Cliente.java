package modelo;

public class Cliente extends Usuario {
	public void calificarProducto(Producto producto, String retroalimentacion) {
		
	}
	
	public void darRetroalimentacion(Producto producto, String retroalimentacion) {
		
	}
	
	public void hacerPedido(Pedido pedido) {
		
	}
}
